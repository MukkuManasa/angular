# angular2-webpack-starter
***
##Install

```
$ npm install
```
## Build (Development)

```
$ npm run build
```
## Build (Production)

```
$ npm run build:prod
```
## Run

```
$ npm run start
```
