import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<h1>Angular2 demo with Webpack</h1>'
})
export class AppComponent { }